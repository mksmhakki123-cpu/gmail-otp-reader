// server.js placeholder
console.log("Hello Gmail OTP Reader");